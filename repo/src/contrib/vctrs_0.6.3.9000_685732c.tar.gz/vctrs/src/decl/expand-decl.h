static inline
enum vctrs_expand_vary parse_vary(r_obj* vary);
