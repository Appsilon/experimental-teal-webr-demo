## revdepcheck results

We checked 4392 reverse dependencies (4359 from CRAN + 33 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 2 new problems
 * We failed to check 7 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* covidcast
  checking re-building of vignette outputs ... ERROR

* scGOclust
  checking re-building of vignette outputs ... ERROR

### Failed to check

* ImputeRobust   (NA)
* loon.ggplot    (NA)
* loon.shiny     (NA)
* MarketMatching (NA)
* Platypus       (NA)
* tidyfit        (NA)
* vivid          (NA)
