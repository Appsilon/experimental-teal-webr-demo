# AirMonitor

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# amt

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# animaltracker

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# anipaths

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# antaresViz

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# AQEval

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# argoFloats

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ARPALData

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# arrow

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ascotraceR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# audrex

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# autostats

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bayesforecast

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bayesmove

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bioRad

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bluebike

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# camtrapR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CDMConnector

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# covid19sf

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cruts

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# csdata

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CSHShydRology

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# csodata

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cubble

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dafishr

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DaMiRseq

<details>

* Version: 2.10.0
* GitHub: NA
* Source code: https://github.com/cran/DaMiRseq
* Date/Publication: 2022-11-01
* Number of recursive dependencies: 245

Run `revdepcheck::revdep_details(, "DaMiRseq")` for more info

</details>

## In both

*   R CMD check timed out
    

*   checking R code for possible problems ... NOTE
    ```
    DaMiR.Clustplot: warning in pheatmap(count_data,
      clustering_distance_rows = d_r, clustering_distance_cols = d_c, scale
      = "row", col = colors, annotation_col = df): partial argument match
      of 'col' to 'color'
    DaMiR.Allplot: no visible binding for global variable ‘X1’
    DaMiR.Allplot: no visible binding for global variable ‘X2’
    DaMiR.Allplot: no visible binding for global variable ‘PC1’
    DaMiR.Allplot: no visible binding for global variable ‘PC2’
    DaMiR.Allplot: no visible binding for global variable ‘value’
    DaMiR.Allplot: no visible binding for global variable ‘variable’
    ...
    DaMiR.ModelSelect: no visible binding for global variable
      ‘N.predictors’
    DaMiR.ModelSelect: no visible binding for global variable ‘Counts’
    DaMiR.iTSadjust: no visible binding for global variable ‘value’
    DaMiR.iTSadjust: no visible binding for global variable ‘variable’
    DaMiR.iTSnorm: no visible binding for global variable ‘value’
    DaMiR.iTSnorm: no visible binding for global variable ‘variable’
    Undefined global functions or variables:
      Accuracy Classifiers Counts MCC Metrics N.predictors NPV PC1 PC2 PPV
      Sensitivity Specificity X1 X2 colSds value variable
    ```

# dataRetrieval

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dataversionr

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# datazoom.amazonia

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# demcon

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# diversitree

<details>

* Version: 0.9-16
* GitHub: NA
* Source code: https://github.com/cran/diversitree
* Date/Publication: 2021-06-11 15:00:10 UTC
* Number of recursive dependencies: 37

Run `revdepcheck::revdep_details(, "diversitree")` for more info

</details>

## In both

*   checking whether package ‘diversitree’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/diversitree/new/diversitree.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘diversitree’ ...
** package ‘diversitree’ successfully unpacked and MD5 sums checked
** using staged installation
checking for gcc... gcc
checking whether the C compiler works... yes
checking for C compiler default output file name... a.out
checking for suffix of executables... 
checking whether we are cross compiling... no
checking for suffix of object files... o
checking whether we are using the GNU C compiler... yes
...
checking for stdint.h... yes
checking for unistd.h... yes
checking fftw3.h usability... no
checking fftw3.h presence... no
checking for fftw3.h... no
configure: WARNING: No fftw found - QuaSSE/fftC will not be available
checking for gsl-config... no
configure: error: gsl-config not found, is GSL installed?
ERROR: configuration failed for package ‘diversitree’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/diversitree/new/diversitree.Rcheck/diversitree’


```
### CRAN

```
* installing *source* package ‘diversitree’ ...
** package ‘diversitree’ successfully unpacked and MD5 sums checked
** using staged installation
checking for gcc... gcc
checking whether the C compiler works... yes
checking for C compiler default output file name... a.out
checking for suffix of executables... 
checking whether we are cross compiling... no
checking for suffix of object files... o
checking whether we are using the GNU C compiler... yes
...
checking for stdint.h... yes
checking for unistd.h... yes
checking fftw3.h usability... no
checking fftw3.h presence... no
checking for fftw3.h... no
configure: WARNING: No fftw found - QuaSSE/fftC will not be available
checking for gsl-config... no
configure: error: gsl-config not found, is GSL installed?
ERROR: configuration failed for package ‘diversitree’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/diversitree/old/diversitree.Rcheck/diversitree’


```
# drake

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dtwSat

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dycdtools

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Ecfun

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# eph

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# epiR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# eurostat

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# excessmort

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# excluder

<details>

* Version: 0.4.0
* GitHub: https://github.com/ropensci/excluder
* Source code: https://github.com/cran/excluder
* Date/Publication: 2022-06-22 15:20:02 UTC
* Number of recursive dependencies: 82

Run `revdepcheck::revdep_details(, "excluder")` for more info

</details>

## In both

*   R CMD check timed out
    

# fable.prophet

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# fastverse

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# FedData

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# finnts

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# fitbitViz

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# flexrsurv

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# foieGras

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gdalcubes

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gemma.R

<details>

* Version: 1.0.0
* GitHub: https://github.com/PavlidisLab/gemma.R
* Source code: https://github.com/cran/gemma.R
* Date/Publication: 2022-11-01
* Number of recursive dependencies: 108

Run `revdepcheck::revdep_details(, "gemma.R")` for more info

</details>

## In both

*   R CMD check timed out
    

*   checking dependencies in R code ... NOTE
    ```
    Unexported object imported by a ':::' call: ‘jsonlite:::simplify’
      See the note in ?`:::` about the use of this operator.
    ```

*   checking R code for possible problems ... NOTE
    ```
    processDEA : <anonymous> : <anonymous>: no visible binding for global
      variable ‘experimental.factorValue’
    Undefined global functions or variables:
      experimental.factorValue
    ```

# geomerge

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggblanket

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggformula

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# grwat

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gtfsrouter

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gumboot

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GWSDAT

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# healthyR.ts

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# highcharter

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# htsr

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# IceSat2R

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# IGoRRR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# janitor

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# lutz

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# macleish

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# maskRangeR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MassWateR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MazamaLocationUtils

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mdsr

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# momentuHMM

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mosaic

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# move

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# moveVis

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mudata2

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# noaastormevents

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# npphen

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# occCite

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# oce

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# oceanmap

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# openairmaps

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# openeo

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# osmdata

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# peakPantheR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```



Error in download.file(url, destfile, method, mode = "wb", ...) : 
  download from 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz' failed
In addition: Warning messages:
1: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 115435743 != reported length 447124147
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 115435743 != reported length 447124147
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘msdata’ failed
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘msdata’ failed


```
### CRAN

```



Error in download.file(url, destfile, method, mode = "wb", ...) : 
  download from 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz' failed
In addition: Warning messages:
1: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 115435743 != reported length 447124147
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 115435743 != reported length 447124147
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘msdata’ failed
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘msdata’ failed


```
# pinochet

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# plotdap

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# pointblank

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# popstudy

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# prism

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# prophet

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PWFSLSmoke

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rasterList

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rbenvo

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rbmi

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rcrimeanalysis

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rfars

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RforProteomics

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```



Error in download.file(url, destfile, method, mode = "wb", ...) : 
  download from 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz' failed
In addition: Warning messages:
1: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 122832052 != reported length 447124147
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 122832052 != reported length 447124147
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
...
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 124493898 != reported length 529395641
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/pRolocdata_1.36.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/pRolocdata_1.36.0.tar.gz': Timeout of 60 seconds was reached
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘pRolocdata’ failed
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘pRolocdata’ failed


```
### CRAN

```



Error in download.file(url, destfile, method, mode = "wb", ...) : 
  download from 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz' failed
In addition: Warning messages:
1: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 122832052 != reported length 447124147
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 122832052 != reported length 447124147
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/msdata_0.38.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
...
2: In download.file(url, destfile, method, mode = "wb", ...) :
  downloaded length 124493898 != reported length 529395641
3: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/pRolocdata_1.36.0.tar.gz': Timeout of 60 seconds was reached
4: In download.file(url, destfile, method, mode = "wb", ...) :
  URL 'https://bioconductor.org/packages/3.16/data/experiment/src/contrib/pRolocdata_1.36.0.tar.gz': Timeout of 60 seconds was reached
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘pRolocdata’ failed
Warning in download.packages(pkgs, destdir = tmpd, available = available,  :
  download of package ‘pRolocdata’ failed


```
# RGENERATEPREC

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rinat

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RmarineHeatWaves

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rnoaa

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rnrfa

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Robyn

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RSAlgaeR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rsinaica

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rtrend

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rts2

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rWind

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SDLfilter

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# semnar

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# sfhotspot

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# simplevis

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# simulariatools

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# sits

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SPARSEMODr

<details>

* Version: 1.2.0
* GitHub: https://github.com/NAU-CCL/SPARSEMODr
* Source code: https://github.com/cran/SPARSEMODr
* Date/Publication: 2022-07-19 20:50:02 UTC
* Number of recursive dependencies: 122

Run `revdepcheck::revdep_details(, "SPARSEMODr")` for more info

</details>

## In both

*   checking whether package ‘SPARSEMODr’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/SPARSEMODr/new/SPARSEMODr.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘SPARSEMODr’ ...
** package ‘SPARSEMODr’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c Nrutil.cpp -o Nrutil.o
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c RcppExports.cpp -o RcppExports.o
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c covid19_model.cpp -o covid19_model.o
covid19_model.cpp:8:10: fatal error: gsl/gsl_rng.h: No such file or directory
    8 | #include <gsl/gsl_rng.h>
      |          ^~~~~~~~~~~~~~~
compilation terminated.
make: *** [/home/vspinu/bin/R-4.2.1-bin/etc/Makeconf:177: covid19_model.o] Error 1
ERROR: compilation failed for package ‘SPARSEMODr’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/SPARSEMODr/new/SPARSEMODr.Rcheck/SPARSEMODr’


```
### CRAN

```
* installing *source* package ‘SPARSEMODr’ ...
** package ‘SPARSEMODr’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c Nrutil.cpp -o Nrutil.o
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c RcppExports.cpp -o RcppExports.o
g++ -std=gnu++14 -I"/home/vspinu/bin/R-4.2.1-bin/include" -DNDEBUG  -I'/media/vspinu/store/Dropbox/dev/lubridate/revdep/library/SPARSEMODr/Rcpp/include' -Wall -Wno-cast-function-type -pedantic   -fpic  -g -O2  -c covid19_model.cpp -o covid19_model.o
covid19_model.cpp:8:10: fatal error: gsl/gsl_rng.h: No such file or directory
    8 | #include <gsl/gsl_rng.h>
      |          ^~~~~~~~~~~~~~~
compilation terminated.
make: *** [/home/vspinu/bin/R-4.2.1-bin/etc/Makeconf:177: covid19_model.o] Error 1
ERROR: compilation failed for package ‘SPARSEMODr’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/SPARSEMODr/old/SPARSEMODr.Rcheck/SPARSEMODr’


```
# spatialrisk

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# spatsurv

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# spectator

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# stats19

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# stppSim

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# strand

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# swfscAirDAS

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tbrf

<details>

* Version: 0.1.5
* GitHub: https://github.com/mps9506/tbrf
* Source code: https://github.com/cran/tbrf
* Date/Publication: 2020-04-09 04:40:02 UTC
* Number of recursive dependencies: 100

Run `revdepcheck::revdep_details(, "tbrf")` for more info

</details>

## In both

*   checking whether package ‘tbrf’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/tbrf/new/tbrf.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘tbrf’ ...
** package ‘tbrf’ successfully unpacked and MD5 sums checked
** using staged installation
** R
** data
*** moving datasets to lazyload DB
** inst
** byte-compile and prepare package for lazy loading
Error in loadNamespace(j <- i[[1L]], c(lib.loc, .libPaths()), versionCheck = vI[[j]]) : 
  there is no package called ‘R6’
Calls: <Anonymous> ... loadNamespace -> withRestarts -> withOneRestart -> doWithOneRestart
Execution halted
ERROR: lazy loading failed for package ‘tbrf’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/tbrf/new/tbrf.Rcheck/tbrf’


```
### CRAN

```
* installing *source* package ‘tbrf’ ...
** package ‘tbrf’ successfully unpacked and MD5 sums checked
** using staged installation
** R
** data
*** moving datasets to lazyload DB
** inst
** byte-compile and prepare package for lazy loading
Error in loadNamespace(j <- i[[1L]], c(lib.loc, .libPaths()), versionCheck = vI[[j]]) : 
  there is no package called ‘R6’
Calls: <Anonymous> ... loadNamespace -> withRestarts -> withOneRestart -> doWithOneRestart
Execution halted
ERROR: lazy loading failed for package ‘tbrf’
* removing ‘/media/vspinu/store/Dropbox/dev/lubridate/revdep/checks/tbrf/old/tbrf.Rcheck/tbrf’


```
# tidybins

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidyfit

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidyquery

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidyrgee

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidytransit

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# timetk

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# track2KBA

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# trackdf

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# trip

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# TUFLOWR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# VicmapR

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# wearables

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# winfapReader

<details>

* Version: 
* GitHub: https://github.com/tidyverse/lubridate
* Source code: NA
* Number of recursive dependencies: 0

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
