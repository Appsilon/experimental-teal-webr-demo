# control_step works with customized parameters

    Code
      res
    Output
      $use_percentile
      [1] FALSE
      
      $bandwidth
      [1] 2.25
      
      $degree
      [1] 0
      
      $num_points
      [1] 39
      

