# control_logistic works with customized parameters

    Code
      res
    Output
      $response_definition
      [1] "response == 'bla'"
      
      $conf_level
      [1] 0.9
      

