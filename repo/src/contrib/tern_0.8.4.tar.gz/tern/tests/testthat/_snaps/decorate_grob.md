# split_string works with default settings

    Code
      res
    Output
      [1] "The species are Iris\nsetosa, versicolor,\nand virginica."

