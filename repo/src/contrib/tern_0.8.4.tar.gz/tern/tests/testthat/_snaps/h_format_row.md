# h_format_row returns the correct dataframe

    Code
      res
    Output
        My Mean             V1
      1    50.0 (48.00, 51.00)

---

    Code
      res
    Output
        My Mean    Mean 95% CI
      1    50.0 (48.00, 51.00)

