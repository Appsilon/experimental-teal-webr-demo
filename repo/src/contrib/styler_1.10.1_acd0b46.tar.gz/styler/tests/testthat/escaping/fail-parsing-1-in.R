#' Example
#'
#' @examples
#' fun() {
#'
#' }
NULL
