# aligned
function(x   = NULL,
         tt  = NULL,
         ayz = NULL) {}


# aligned
k <- function(x   = NULL,
              aq  = NULL,
              ayz = NULL) {}


# aligned, eq right
function(x   =  2,
         tt  =  1,
         ayz = 99) {}

# aligned, eq left
function(x =    2,
         tt =   1,
         ayz = 99) {}


# not aligned
k <- function(x =   fish,
              aq =     21,
              ayz = t(322)) {}

# aligned
k <- function(x = flus(we),
              aq =  x - 22, k = 22,
              ayz = m(jk5), xfea =  3) {}


# aligned
k <- function(x = flus(we),
              aq =  x - 22,    k = 22,
              ayz = m(jk5), xfea =  3) {}
