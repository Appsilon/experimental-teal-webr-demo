#' Do stuff
#'
#' Some things we do
#' @examples
#' g()
#' \dontrun{
#' f(x)
#' }
#'
#' @export
g()
