#' This
#'
#'
#' is stuff
#'
#' @examples
#' 1+1


# nolint start
#' @examplesIf long_condition_line
#' 32 / 3
# nolint end
