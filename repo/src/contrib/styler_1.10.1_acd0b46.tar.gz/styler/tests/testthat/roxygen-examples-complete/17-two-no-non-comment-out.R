#' @examples
#' my_fun <- function() {
#'   print("hello world!")
#' }
#' # before this comment is a left-over space
#' another_function <- function() NULL

#' @examples
#' my_fun <- function() {
#'   print("hello world!")
#' }
#' # before this comment is a left-over space
#' another_function <- function() NULL
