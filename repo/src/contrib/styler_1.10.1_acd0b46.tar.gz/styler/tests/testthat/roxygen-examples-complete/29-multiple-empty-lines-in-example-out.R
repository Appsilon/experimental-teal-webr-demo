#' Empty line in examples
#'
#' @examples
1

#' Empty line in examples
#'
#' @examples
#' \dontrun{
#'
#' }
2
