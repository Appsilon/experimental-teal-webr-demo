# random
this(is_a_call(x))
if (x) {
}
