c(x = 2)

c(
  x =
    2
)

c(
  x = 2
)

c(
  x = 2
)

c(
  x = 2,
  a =
    1
)


c(
  x = 2,
  a = # stuff
    1
)


c(
  b = 4, x # comment
  = 2
)


c(
  x = # comment
    2, c =
  )
