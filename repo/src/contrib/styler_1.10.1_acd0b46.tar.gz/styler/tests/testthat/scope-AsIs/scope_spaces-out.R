a <- function() {
                    1 + 1
d = 3
    }
