a <- function(x, #
y
) {
  x - 1
}


a <- function(x, #
  y) #
{
  x
}

function(a =
           b,
         c) {}

function(a =
           b,
         c) {

}

function(a =
           b,
         c
) {}
