while(x == 2) h(
  2
)

while(x == 2) h( # comment
  2
)

while(x == 2 &&
      2 + 2 == 2) h(
  2
)


for(x in 1:22) h(
  2
)

for(x in 1:22) h( # comment
  2
)

for(k in f(
  2:22
)) h(
        2
      )

for(k in f(
  2:22 # comment
)) h(2)
