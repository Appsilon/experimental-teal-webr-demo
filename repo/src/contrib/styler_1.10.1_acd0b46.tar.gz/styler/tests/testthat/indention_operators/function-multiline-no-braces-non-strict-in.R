g <- function(k)
  NULL


g <- function(k) h(
  NULL
)


g <- function(k) h( # y
  NULL # x
)

g <- function(k) h( # y
  NULL
)


g <- function(k) h(
  NULL # 3jkö
)

g <- function(k) h(
  if (TRUE)
    x
)
