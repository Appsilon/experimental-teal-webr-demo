test_that(key(
  s
), x = 1)

test_that(
  key(
    s
  ),
  x = 1
)


test_that(key(
  s
), x = 1)


test_that(
  key(s),
  x = 1
)
