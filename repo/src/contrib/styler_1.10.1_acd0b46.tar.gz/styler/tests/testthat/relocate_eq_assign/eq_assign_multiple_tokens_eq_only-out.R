a <- b <- c <- d <- e <- f <- g <- 4
a <- 3
b <- c <- d <- ey <- 4
a <- 3
b <- c <- d <- ey <- 4
ff <- 3
b <- c <- d <- 3
g <- 4
ge <- 5
