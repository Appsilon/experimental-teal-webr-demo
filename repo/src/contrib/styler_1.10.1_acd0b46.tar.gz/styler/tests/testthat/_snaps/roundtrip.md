# correct styling does not give an error

    Code
      verify_roundtrip("1+1", "1 + 1")

# corrupt styling does give an error

    The expression evaluated before the styling is not the same as the expression after styling. This should not happen.
    i This is an internal error that was detected in the styler package.
      Please report it at <https://github.com/r-lib/styler/issues> with a reprex (<https://tidyverse.org/help/>) and the full backtrace.

