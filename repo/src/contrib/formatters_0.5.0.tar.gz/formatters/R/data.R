## data

#' DM data
#'
#' @format rds (data.frame)
"DM"



#' Simulated CDISC Alike Data for Examples
#'
#' @format rds (data.frame)
#' @rdname cdisc_data
"ex_adsl"

#' @rdname cdisc_data
"ex_adae"

#' @rdname cdisc_data
"ex_adaette"

#' @rdname cdisc_data
"ex_adtte"

#' @rdname cdisc_data
"ex_adcm"

#' @rdname cdisc_data
"ex_adlb"

#' @rdname cdisc_data
"ex_admh"

#' @rdname cdisc_data
"ex_adqs"

#' @rdname cdisc_data
"ex_adrs"

#' @rdname cdisc_data
"ex_advs"
