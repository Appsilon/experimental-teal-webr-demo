## Deferred validation

This example app shows that input validation feedback can be deferred until after the user presses Submit.

Note also that the email input is not required, but if provided, it must be valid.
