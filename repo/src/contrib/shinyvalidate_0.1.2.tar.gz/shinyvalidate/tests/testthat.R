library(testthat)
library(shinyvalidate)

test_check("shinyvalidate")
