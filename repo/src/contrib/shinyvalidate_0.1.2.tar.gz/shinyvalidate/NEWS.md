# shinyvalidate 0.1.2

* Support HTML messages when failing a validation. (#55)

# shinyvalidate 0.1.1

* Fix an incompatibility between jQueryUI and shinyvalidate. (#32)

# shinyvalidate 0.1.0

* New package with 18 functions and one R6 class (`InputValidator`).
