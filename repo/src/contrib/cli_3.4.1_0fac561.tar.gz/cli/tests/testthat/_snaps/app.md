# stop_app() errors

    Code
      stop_app(1:10)
    Condition
      Error:
      ! `app` must be a CLI app
      i `app` is an integer vector

