# errors

    Code
      make_ansi_style(1:10)
    Condition
      Error:
      ! `style` must be an ANSI style
      i an ANSI style is a character scalar (cli style name, RGB or R color name), or a [3x1] or [4x1] numeric RGB matrix
      i `style` is an integer vector

