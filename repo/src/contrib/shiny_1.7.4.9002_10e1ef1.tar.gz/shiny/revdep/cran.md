## revdepcheck results

We checked 1039 reverse dependencies (1038 from CRAN + 1 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 4 packages

Issues with CRAN packages are summarised below.

### Failed to check

* ctsem      (NA)
* diveR      (NA)
* loon.shiny (NA)
* SSVS       (NA)
