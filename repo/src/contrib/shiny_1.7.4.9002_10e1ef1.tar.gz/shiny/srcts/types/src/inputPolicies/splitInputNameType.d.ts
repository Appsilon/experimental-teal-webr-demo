declare function splitInputNameType(nameType: string): {
    name: string;
    inputType: string | "";
};
export { splitInputNameType };
