import type { Shiny } from ".";
declare function initShiny(windowShiny: Shiny): void;
export { initShiny };
