declare function resetBrush(brushId: string): void;
export { resetBrush };
