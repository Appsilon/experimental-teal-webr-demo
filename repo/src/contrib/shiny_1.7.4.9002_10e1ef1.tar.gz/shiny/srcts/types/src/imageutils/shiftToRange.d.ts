declare function shiftToRange(vals: number[] | number, min: number, max: number): number[];
export { shiftToRange };
