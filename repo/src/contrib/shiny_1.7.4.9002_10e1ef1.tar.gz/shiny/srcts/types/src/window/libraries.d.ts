import type { Shiny } from "../shiny";
declare function windowShiny(): Shiny;
export { windowShiny };
