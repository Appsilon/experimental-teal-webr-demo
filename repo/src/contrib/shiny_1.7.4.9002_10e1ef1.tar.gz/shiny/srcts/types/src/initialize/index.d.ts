declare function init(): void;
export { init };
