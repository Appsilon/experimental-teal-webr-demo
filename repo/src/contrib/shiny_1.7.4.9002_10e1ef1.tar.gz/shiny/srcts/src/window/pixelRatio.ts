function windowDevicePixelRatio(): number {
  return window.devicePixelRatio;
}

export { windowDevicePixelRatio };
