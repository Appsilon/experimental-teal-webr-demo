import { init } from "./initialize";

init();
