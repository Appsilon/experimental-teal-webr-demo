library(testthat)
library(shinyTree)

test_check("shinyTree")
