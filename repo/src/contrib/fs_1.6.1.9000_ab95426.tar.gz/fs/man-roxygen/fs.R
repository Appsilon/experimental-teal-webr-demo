#' @param path A character vector of one or more paths.
